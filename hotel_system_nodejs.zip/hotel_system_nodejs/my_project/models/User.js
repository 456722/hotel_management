//require mongoose, passport-Local-mongoose
const mongoose = require('mongoose');
const passportLocalMongoose = require('passport-local-mongoose');

const validator = require("email-validator");

// Create User Schema
const userSchema = new mongoose.Schema({
   username: {
     type: String,
     unique:true,
     autoIndex:true,
   },

    firstname:{
    type:String,
    required:[true,"Please Enter Provide first Name"]
    },

    lastname:{
      type:String,

      },

   email:{
     type:String,
     required:[true,"Please Enter your email"],
     unique:true,
     autoIndex:true,
     lowercase:true,
     validate:{
     validator: function(v){
      return validator.isEmail(v);
     },
     message:"invalid email provide",
     },
   },
   password: {
    type:String,
    required:[true,"Please Enter your password"],
    minlength:8,
    validate: {
      validator:function(v){
     return v === this.password
      },
    
    }
   },
   passwordconfirm: {
    type: [String], // Assuming passwordconfirm is an array of strings
    required: [true,"pleae Enter your confirm password"],
    minlength:8,
  },
   role:{
    type:String,
    enum:['user','elivatouser','admin'],
    default:'user',
   },
});


// hash password using passport-Local-mongoose plugin userSchema.plugin (passportLocalMongoose);
userSchema.plugin(passportLocalMongoose)

//export User model
module.exports = mongoose.model('User', userSchema);